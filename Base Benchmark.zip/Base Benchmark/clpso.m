function [T,gbest] = clpso(funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax)
% global funtest 
rand('state',sum(100*clock));
c = 2.0;
m=7;
D = Dimension;
sizepop = Particle_Number;
maxfes = Max_FES;
maxgen = fix(maxfes/sizepop);
if length(popmin)==1
    popmin=repmat(popmin,1,D);
    popmax=repmat(popmax,1,D);
end

if length(Vmin)==1
    Vmin=repmat(Vmin,1,D);
    Vmax=repmat(Vmax,1,D);
end

pop=zeros(sizepop,D);
V=zeros(sizepop,D);
fitness=zeros(sizepop,1);
T=zeros(maxgen,3);
flag=zeros(sizepop,1);
fbest=zeros(sizepop,D);
Pc=zeros(sizepop,1);
for i=1:sizepop
     Pc(i) = 0.05 + 0.45 * (exp(10*(i-1)/(sizepop-1))-1)/(exp(10)-1);
end
% 随机产生一个种群
for i = 1:sizepop
    pop(i,:) = popmin+(popmax-popmin)./2.*rand(1,D);    %初始种群
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %初始化速度
end
fitness = feval(funtest,pop,func_num);
fes=sizepop;

fitnesspbest = fitness;
pbest = pop;
[fitnessgbest,bestindex] = min(fitnesspbest);
gbest = pbest(bestindex,:);   

T(1,1)=fes;
T(1,2)=fitnessgbest; 
T(1,3)=0;
i=0;
% 迭代寻优
while fes<maxfes
    i=i+1;
%     w=0.9-0.5*i/maxgen;
    w=0.9-0.5*fes/maxfes;
    for j = 1:sizepop
        if flag(j)>=m
            r=rand(1,D);
            for d = 1:D
                if r(d)<Pc(j)
                    f=randi(sizepop,2,1);
                    F1=fitnesspbest(f(1));
                    F2= fitnesspbest(f(2));

                    if F1<F2
                        fbest(j,d)=pbest(f(1),d);
                    else
                        fbest(j,d)=pbest(f(2),d);
                    end
                else   
                    fbest(j,d)=pbest(j,d);     
                end
            end 
            if fbest(j,:)==pbest(j,:)
                d=randi(D);
                k=randi(sizepop);
                while k==j
                    k=randi(sizepop);
                end
                fbest(j,d)=pbest(k,d);
            end              
            flag(j)=0;
%         else
%             fbest(j,:)=pbest(j,:);
        end
        % 速度更新
        V(j,:) = w*V(j,:) + c*rand(1,D).*(fbest(j,:) - pop(j,:));      
        %确保速度不超出边界
        V(j,:)=(V(j,:)>Vmax).*Vmax+(V(j,:)<=Vmax).*V(j,:);
        V(j,:)=(V(j,:)<Vmin).*Vmin+(V(j,:)>=Vmin).*V(j,:);
        % 种群更新
        pop(j,:) = pop(j,:) + V(j,:);
%         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
%             +(pop(j,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(j,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
            +(pop(j,:)<popmin).*popmin+(pop(j,:)>popmax).*popmax;
        %判断粒子位置是否超出边界
%         e=sum(pop(j,:)>popmax)+sum(pop(j,:)<popmin);
%         if e==0
              % 适应度值更新
              fitness(j) = feval(funtest,pop(j,:),func_num);
              fes=fes+1;
              %pbest和gbest更新
              if fitness(j) < fitnesspbest(j)
                  fitnesspbest(j) =fitness(j);
                  pbest(j,:) =pop(j,:);
                  flag(j)=0;
                  temp=(fitness(j) < fitnessgbest);
                  fitnessgbest =temp * fitness(j)+(1-temp)*fitnessgbest;
                  gbest = temp.*pop(j,:)+(1-temp).*gbest;
%                   bestindex=temp*j+(1-temp).*bestindex;
              else
                  flag(j)=flag(j)+1;
              end
              if rem(fes,sizepop)==0
                   T(fix(fes / sizepop),1)=fes;
                   T(fix(fes / sizepop),2)=fitnessgbest; 
                   T(fix(fes / sizepop),3)=i; 
              end 
%         end          
    end
end
T=T(1:fix(maxfes / sizepop),:);
end