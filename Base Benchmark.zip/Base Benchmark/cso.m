function [T,gbest] = cso(funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax)
% global funtest
rand('state',sum(100*clock));
D = Dimension;
sizepop = Particle_Number;
maxfes = Max_FES;
maxgen = fix(2*maxfes/sizepop)+1;
if length(popmin)==1
    popmin=repmat(popmin,1,D);
    popmax=repmat(popmax,1,D);
end

if length(Vmin)==1
    Vmin=repmat(Vmin,1,D);
    Vmax=repmat(Vmax,1,D);
end
pop=zeros(sizepop,D);
V=zeros(sizepop,D);
fitness=zeros(sizepop,1);
T=zeros(fix(maxfes / sizepop),3);
if sizepop<=100
    lambda=0;
else
    lambdamin=0.14*log10(sizepop)-0.30;
    lambdamax=0.27*log10(sizepop)-0.51;
    lambda=(lambdamin+lambdamax)/2;
end
    
for i = 1:sizepop
    % 随机产生一个种群
    pop(i,:) = popmin+(popmax-popmin).*rand(1,D);    %初始种群
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %初始化速度
end
fitness = feval(funtest,pop,func_num);
fes=sizepop;
[fitnessgbest,bestindex] = min(fitness);
gbest = pop(bestindex,:); 

T(1,1)=fes;
T(1,2)=fitnessgbest;
T(1,3)=0;
for i=1:maxgen
    if fes>=maxfes
        break;
    end
    %随机构建竞争对
    index = randperm(sizepop);
    pop = pop(index,:);
    V=V(index,:);
    fitness = fitness(index);
    pmean = Cal_pmean(pop);
    %竞争
    for j = 1:2:sizepop-1
        F1 = fitness(j);
        F2 = fitness(j+1);
        if F1>=F2
            V(j,:) = rand(1,D).*V(j,:) +rand(1,D).*(pop(j+1,:) - pop(j,:)) + lambda*rand(1,D).*(pmean- pop(j,:));
            %确保速度不超出边界
            V(j,:)=(V(j,:)>Vmax).*Vmax+(V(j,:)<=Vmax).*V(j,:);
            V(j,:)=(V(j,:)<Vmin).*Vmin+(V(j,:)>=Vmin).*V(j,:);
            % 种群更新
            pop(j,:) = pop(j,:) + V(j,:);
            %确保粒子位置不超出边界
%             pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
%             +(pop(j,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(j,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
            +(pop(j,:)<popmin).*popmin+(pop(j,:)>popmax).*popmax;

            % 适应度值更新
            fitness(j) = feval(funtest,pop(j,:),func_num);
            if fitness(j)<fitnessgbest
                fitnessgbest=fitness(j);
                gbest=pop(j,:);       
            end
        else
            V(j+1,:) = rand(1,D).*V(j+1,:) +rand(1,D).*(pop(j,:) - pop(j+1,:)) + lambda*rand(1,D).*(pmean- pop(j+1,:));
            %确保速度不超出边界
            V(j+1,:)=(V(j+1,:)>Vmax).*Vmax+(V(j+1,:)<=Vmax).*V(j+1,:);
            V(j+1,:)=(V(j+1,:)<Vmin).*Vmin+(V(j+1,:)>=Vmin).*V(j+1,:);
            % 种群更新
            pop(j+1,:) = pop(j+1,:) + V(j+1,:);
            %确保粒子位置不超出边界
%             pop(j+1,:)=((pop(j+1,:)>=popmin)&(pop(j+1,:)<=popmax)).*pop(j+1,:)...
%             +(pop(j+1,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(j+1,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
            pop(j+1,:)=((pop(j+1,:)>=popmin)&(pop(j+1,:)<=popmax)).*pop(j+1,:)...
            +(pop(j+1,:)<popmin).*popmin+(pop(j+1,:)>popmax).*popmax;

            % 适应度值更新
            fitness(j+1) = feval(funtest,pop(j+1,:),func_num); 
            if fitness(j+1)<fitnessgbest
                fitnessgbest=fitness(j+1);
                gbest=pop(j+1,:);
            end
        end
        fes=fes+1;
        if rem(fes,sizepop)==0
           T(fix(fes / sizepop),1)=fes;
           T(fix(fes / sizepop),2)=fitnessgbest;
           T(fix(fes / sizepop),3)=i;   
        end       
    end
end
T=T(1:fix(maxfes / sizepop),:);
end
function [pmean] = Cal_pmean(X)
%CAL_PMEAN 计算Xmean 
    pmean = mean(X,1);
end