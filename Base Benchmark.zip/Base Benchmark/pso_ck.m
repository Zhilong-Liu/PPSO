function [T,gbest] =pso_ck( funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax)
rand('state',sum(100*clock));
c1 = 2.05;
c2 = 2.05;
chi= 0.729;
D = Dimension;
sizepop = Particle_Number;
maxfes=Max_FES;
maxgen = fix(maxfes/sizepop);
if length(popmin)==1
    popmin=repmat(popmin,1,D);
    popmax=repmat(popmax,1,D);
end
if length(Vmin)==1
    Vmin=repmat(Vmin,1,D);
    Vmax=repmat(Vmax,1,D);
end

pop=zeros(sizepop,D);
V=zeros(sizepop,D);
fitness=zeros(sizepop,1);
T=zeros(maxgen,3);

for i = 1:sizepop
    % 随机产生一个种群
    pop(i,:) = popmin+(popmax-popmin).*rand(1,D);    %初始种群
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %初始化速度
end
fitness = feval(funtest,pop,func_num);
fes=sizepop;
pbest = pop;    %个体最佳
fitnesspbest = fitness;%个体最佳适应度值
%个体极值和群体极值
[fitnessgbest,bestindex] = min(fitnesspbest);
gbest = pbest(bestindex,:); 
T(1,1)=fes;
T(1,2)=fitnessgbest; 
T(1,3)=0;

for i = 1:maxgen
    if fes>=maxfes
        break;
    end
    for j = 1:sizepop
        % 速度更新
        V(j,:) = chi.*(V(j,:) + c1*rand(1,D).*(pbest(j,:) - pop(j,:)) + c2*rand(1,D).*(gbest - pop(j,:)));      
        %确保速度不超出边界
        V(j,:)=(V(j,:)>Vmax).*Vmax+(V(j,:)<=Vmax).*V(j,:);
        V(j,:)=(V(j,:)<Vmin).*Vmin+(V(j,:)>=Vmin).*V(j,:);
        % 种群更新
        pop(j,:) = pop(j,:) + V(j,:);
        %确保粒子位置不超出边界
%         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
%             +(pop(j,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(j,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
        pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
            +(pop(j,:)<popmin).*popmin+(pop(j,:)>popmax).*popmax;

        fitness(j) = feval(funtest,pop(j,:),func_num);
        fes=fes+1;
        if fitness(j) < fitnesspbest(j)
            pbest(j,:) = pop(j,:);
            fitnesspbest(j) = fitness(j);   
        end
        if fitness(j) < fitnessgbest
            gbest = pop(j,:);
            fitnessgbest = fitness(j);
        end  
        if rem(fes,sizepop)==0
           T(fix(fes / sizepop),1)=fes;
           T(fix(fes / sizepop),2)=fitnessgbest; 
           T(fix(fes / sizepop),3)=i; 
        end 
    end    
end
T=T(1:fix(maxfes / sizepop),:); 
end