function [T,gbest] =dms_l_pso_l(funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax)
% global funtest
rand('state',sum(100*clock));
sizepop=Particle_Number;
gnum=2;
gsizepop=sizepop/gnum;
D=Dimension;
maxfes=Max_FES;
L_FES=3*D;
L_num=ceil(0.25.*gnum);
c=[1.49445 1.49445];   %acceleration constants
w=0.729;
% fhd='benchmark_func';
pop=zeros(sizepop,D);
V=zeros(sizepop,D);
fitness=zeros(sizepop,1);
T=zeros(ceil(maxfes/sizepop),3);
% iwt=0.9-(1:me)*(0.7/me);
if length(popmin)==1
    popmin=repmat(popmin,1,D);
    popmax=repmat(popmax,1,D);
end
if length(Vmin)==1
    Vmin=repmat(Vmin,1,D);
    Vmax=repmat(Vmax,1,D);
end
for i = 1:sizepop
    % 随机产生一个种群
    pop(i,:) = popmin+(popmax-popmin).*rand(1,D);    %初始种群
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %初始化速度
end
fitness= feval(funtest,pop,func_num);
fes=sizepop;
pbest = pop;    
fitnesspbest = fitness;
[fitnessgbest,bestindex] = min(fitness);
gbest = pop(bestindex,:);   %全局最佳
T(1,1)=fes;
T(1,2)=fitnessgbest;
T(1,3)=0;
groupid=[];groupgbest=[];fitnessgroupgbest=[];
for i=1:gnum
    groupid(i,:)=[((i-1)*gsizepop+1):i*gsizepop];
    posgroup(groupid(i,:))=i;
    [fitnessgroupgbest(i),groupgbestid(i)]=min(fitnesspbest(groupid(i,:)));
    groupgbest(i,:)=pbest(groupid(i,groupgbestid(i)),:);%initialize the gbest and the gbest's fitness value
end
get_flag=0;
i=0;
while fes<Max_FES    
    i=i+1;
    for j=1:sizepop
        r=rand(1,D);
        for d = 1:D
            if r(d)<0.5
               V(j,d)=w*V(j,d)+c(1)*rand*(pbest(j,d)-pop(j,d))+c(2)*rand*(groupgbest(posgroup(j),d)-pop(j,d)); 
               V(j,d) = max(Vmin(d),min(Vmax(d),V(j,d)));
               pop(j,d)=pop(j,d)+V(j,d);
            else
                pop(j,d)=pbest(j,d);
            end
        end
%         if (sum(pop(j,:)>popmax)+sum(pop(j,:)<popmin))==0
        pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
            +(pop(j,:)<popmin).*popmin+(pop(j,:)>popmax).*popmax;
   
            fitness(j)=feval(funtest,pop(j,:),func_num);
            fes=fes+1;
            temp=(fitnesspbest(j)<fitness(j));
            pbest(j,:)=temp*pbest(j,:)+(1-temp)*pop(j,:);
            fitnesspbest(j)=temp*fitnesspbest(j)+(1-temp)*fitness(j);%update the pbest
            if fitness(j)<fitnessgroupgbest(posgroup(j))
                groupgbest(posgroup(j),:)=pop(j,:);
                fitnessgroupgbest(posgroup(j))=fitness(j);
            end   
            if fitness(j)<fitnessgbest
                gbest=pop(j,:);
                fitnessgbest=fitness(j);
                bestindex=j;
            end 
            if rem(fes,sizepop)==0
               T(fix(fes / sizepop),1)=fes;
               T(fix(fes / sizepop),2)=fitnessgbest;
               T(fix(fes / sizepop),3)=i;              
            end 
%         end    
    end   
    
    
%     if change_flag==1|mod(i,5)==0
   
end

T=T(1:fix(maxfes / sizepop),:);
end
