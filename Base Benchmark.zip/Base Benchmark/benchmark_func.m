function f=benchmark_func(x,func_num)
global initial_flag
persistent fhd %f_bias

if initial_flag==0
   if func_num==1      fhd=str2func('Shift_Sphere'); %[-100,100]
    elseif func_num==2  fhd=str2func('Shift_Schwefel_2_22'); %[-10,10]
    elseif func_num==3  fhd=str2func('Shift_Schwefel_1_2'); %[-100, 100]
    elseif func_num==4  fhd=str2func('Shift_Schwefel_2_21'); %[-100,100]
    elseif func_num==5  fhd=str2func('Shift_Rosenbrock'); %[-90,180]
    elseif func_num==6  fhd=str2func('Shift_Step'); %[-100,100]
    elseif func_num==7  fhd=str2func('Shift_Quartic_Noise'); %[-1.28,1.28]
    elseif func_num==8  fhd=str2func('Shift_Weierstrass'); %[-500,500]
    elseif func_num==9  fhd=str2func('Shift_Rastrigin'); %[-5.12,5.12]
    elseif func_num==10  fhd=str2func('Shift_Ackley'); %[-32,32]
    elseif func_num==11  fhd=str2func('Shift_Griewank'); %[-600,600]
    elseif func_num==12  fhd=str2func('Shift_Penalized_1'); %[-50,50]
    elseif func_num==13  fhd=str2func('Shift_Penalized_2'); %[-50,50]
%     elseif func_num==14  fhd=str2func('Shift_Quartic_Noise'); %[-100,100]
    end
    %f_bias = [-450 -450 390 -330 -180 -140 0];
%     load fbias_data;
end
f=feval(fhd,x);
% f=feval(fhd,x)+f_bias(func_num);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%Unimodal%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 	1.Shifted Sphere Function 
function fit=Shift_Sphere(x)
    global initial_flag
    persistent o
    [ps,D]=size(x);
    if initial_flag==0
        load benchmark\Shift_Sphere_data
        if length(o)>=D
             o=o(1:D);
        else
             o=-100+200*rand(1,D);
        end
        initial_flag=1;
    end
    x=x-repmat(o,ps,1);
    fit=sum(x.^2,2);
end

% 2. Shifted Schwefel's Problem 2.22
function fit=Shift_Schwefel_2_22(x)
    global initial_flag
    persistent o
    [ps,D]=size(x);
    if initial_flag==0
        load benchmark\Shift_Schwefel_2_22_data
        if length(o)>=D
             o=o(1:D);
        else
             o=-10+20*rand(1,D);
        end
        initial_flag=1;
    end
    x=x-repmat(o,ps,1);
    fit=sum(abs(x),2)+prod(abs(x),2);
end

% 3. Shifted Schwefel's Problem 1.2
function fit = Shift_Schwefel_1_2(x)
   global initial_flag
   persistent o
   [ps, D] = size(x);
   if (initial_flag == 0)
      load benchmark\Shift_Schwefel_1_2_data
      if length(o) >= D
          o=o(1:D);
      else
          o=-100+200*rand(1,D);
      end
      initial_flag = 1;
   end
   x=x-repmat(o,ps,1);
   fit=0;
   for i=1:D
       fit=fit+sum(x(:,1:i),2).^2;
   end
end

% 4. Shifted Schwefel's Problem 2.21
function fit = Shift_Schwefel_2_21(x)
   global initial_flag
   persistent o
   [ps, D] = size(x);
   if (initial_flag == 0)
      load benchmark\Shift_Schwefel_2_21_data
      if length(o) >= D
          o=o(1:D);
      else
          o=-100+200*rand(1,D);
      end
      initial_flag = 1;
   end
   x=x-repmat(o,ps,1);
   fit=max(abs(x),[],2);
end

% 5. Shifted Rosenbrock's Function
function fit = Shift_Rosenbrock(x)
   global initial_flag
   persistent o
   [ps, D] = size(x);
   if (initial_flag == 0)
      load benchmark\Shift_Rosenbrock_data
      if length(o) >= D
          o=o(1:D);
      else
          o=-90+180*rand(1,D);
      end
      initial_flag = 1;
   end
    x=x-repmat(o,ps,1)+1;
    fit=sum(100.*(x(:,1:D-1).^2-x(:,2:D)).^2+(x(:,1:D-1)-1).^2,2);
end

% 6. Shift Step Function
function fit = Shift_Step(x)
   global initial_flag
   persistent o
   [ps, D] = size(x);
   if (initial_flag == 0)
      load benchmark\Shift_Step_data
      if length(o) >= D
          o=o(1:D);
      else
          o=-100+200*rand(1,D);
      end
      initial_flag = 1;
   end
    x=x-repmat(o,ps,1);
    fit=sum(floor(x+.5).^2,2);
end

% 7. Shift Quartic Noise Function
function fit = Shift_Quartic_Noise(x)
   global initial_flag
   persistent o
   [ps, D] = size(x);
   if (initial_flag == 0)
      load benchmark\Shift_Quartic_Noise_data
      if length(o) >= D
          o=o(1:D);
      else
          o=-1.28+2.56*rand(1,D);
      end
      initial_flag = 1;
   end
    x=x-repmat(o,ps,1);
    fit=sum([1:D].*(x.^4),2)+rand(ps,1);
end

% 	8.Shifted Weierstrass Function
function fit=Shift_Weierstrass(x)
global initial_flag
persistent o 
[ps,D]=size(x);
if initial_flag==0
    load benchmark\Shift_Weierstrass_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-0.5+0.5*rand(1,D);
    end
    c=5;
    initial_flag=1;
end
x=x-repmat(o,ps,1);
x=x+0.5;
a = 0.5;%0<a<1
b = 3;
kmax = 20;
[ps,D]=size(x);

c1(1:kmax+1) = a.^(0:kmax);
c2(1:kmax+1) = 2*pi*b.^(0:kmax);
c=-w(0.5,c1,c2);
fit=0;
for i=1:D
fit=fit+w(x(:,i)',c1,c2);
end
fit=fit+repmat(c*D,ps,1);
end
function y = w(x,c1,c2)
y = zeros(length(x),1);
for k = 1:length(x)
	y(k) = sum(c1 .* cos(c2.*x(:,k)));
end
end
% % 8. Schwefel's Problem 2.26
% function fit = Schwefel_2_26(x)
%     fit=sum(-x.*sin(sqrt(abs(x))),2)+12569.5;
% end

% % 8. Shifted Schwefel's Problem 2.26
% function fit = Shift_Schwefel_2_26(x)
%    global initial_flag
%    persistent o
%    [ps, D] = size(x);
%    if (initial_flag == 0)
%       load benchmark\Shift_Schwefel_2_26_data
%       if length(o) >= D
%           o=o(1:D);
%       else
%           o=-500+1000*rand(1,D);
%       end
%       initial_flag = 1;
%    end
%     x=x-repmat(o,ps,1)+420.9687;
%     fit=sum(-x.*sin(sqrt(abs(x))),2)+12569.5;
% end

% 9.Shifted Rastrign's Function
function fit=Shift_Rastrigin(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load benchmark\Shift_Rastrigin_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-5.12+10.24*rand(1,D);
    end
    initial_flag=1;
end
x=x-repmat(o,ps,1);
fit=sum(x.^2-10.*cos(2.*pi.*x)+10,2);
end

% 	10.Shifted Ackley's Function
function fit=Shift_Ackley(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load benchmark\Shift_Ackley_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-32+64*rand(1,D);
    end
    initial_flag=1;
end
x=x-repmat(o,ps,1);
fit=sum(x.^2,2);
fit=20-20.*exp(-0.2.*sqrt(fit./D))-exp(sum(cos(2.*pi.*x),2)./D)+exp(1);
end

% 11.Shifted Griewank's Function
function fit=Shift_Griewank(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load benchmark\Shift_Griewank_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-600+1200*rand(1,D);
    end
    o=o(1:D);
    initial_flag=1;
end
x=x-repmat(o,ps,1);
fit=1;
for i=1:D
    fit=fit.*cos(x(:,i)./sqrt(i));
end
fit=sum(x.^2,2)./4000-fit+1;
end

% 12.Shift Penalized 1 Function
function fit=Shift_Penalized_1(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load benchmark\Shift_Penalized_1_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-50+100*rand(1,D);
    end
    o=o(1:D);
    initial_flag=1;
end
x=x-repmat(o,ps,1)+1;
fit=(pi/D).*(10.*((sin(pi.*(1+(x(:,1)+1)/4))).^2)+sum((((x(:,1:D-1)+1)./4).^2).*...
(1+10.*((sin(pi.*(1+(x(:,2:D)+1)./4)))).^2),2)+((x(:,D)+1)/4).^2)+sum(Ufun(x,10,100,4),2);
end

% 13.Shift Penalized 2 Function
function fit=Shift_Penalized_2(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load benchmark\Shift_Penalized_2_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-50+100*rand(1,D);
    end
    o=o(1:D);
    initial_flag=1;
end
x=x-repmat(o,ps,1)+1;
fit=.1*((sin(3*pi*x(:,1))).^2+sum((x(:,1:D-1)-1).^2.*(1+(sin(3.*pi.*x(:,2:D))).^2),2)+...
((x(:,D)-1).^2).*(1+(sin(2*pi.*x(:,D))).^2))+sum(Ufun(x,10,100,4),2);
end

function f = Ufun(x,a,k,m)
[ps,D]=size(x);
for j=1:ps
for i=1:D
    if x(j,i)>a
        f(j,i)=k*(x(j,i)-a)^m;
    elseif -a<=x(j,i)<a
        f(j,i)=0;
    else
        f(j,i)=k*(-x(j,i)-a)^m;
    end
end
end
end

% function o = F14(x)
% aS=[-32 -16 0 16 32 -32 -16 0 16 32 -32 -16 0 16 32 -32 -16 0 16 32 -32 -16 0 16 32;,...
% -32 -32 -32 -32 -32 -16 -16 -16 -16 -16 0 0 0 0 0 16 16 16 16 16 32 32 32 32 32];
% for j=1:25
%     bS(j)=sum((x'-aS(:,j)).^6);
% end
% o=(1/500+sum(1./([1:25]+bS))).^(-1);
% end
% function o = F15(x)
% aK=[.1957 .1947 .1735 .16 .0844 .0627 .0456 .0342 .0323 .0235 .0246];
% bK=[.25 .5 1 2 4 6 8 10 12 14 16];bK=1./bK;
% o=sum((aK-((x(1).*(bK.^2+x(2).*bK))./(bK.^2+x(3).*bK+x(4)))).^2);
% end
% function o = F16(x)
% o=4*(x(1)^2)-2.1*(x(1)^4)+(x(1)^6)/3+x(1)*x(2)-4*(x(2)^2)+4*(x(2)^4);
% end
% function o = F17(x)
% o=(x(2)-(x(1)^2)*5.1/(4*(pi^2))+5/pi*x(1)-6)^2+10*(1-1/(8*pi))*cos(x(1))+10;
% end
% function o = F18(x)
% o=(1+(x(1)+x(2)+1)^2*(19-14*x(1)+3*(x(1)^2)-14*x(2)+6*x(1)*x(2)+3*x(2)^2))*...
%     (30+(2*x(1)-3*x(2))^2*(18-32*x(1)+12*(x(1)^2)+48*x(2)-36*x(1)*x(2)+27*(x(2)^2)));
% end
% function o = F19(x)
% aH=[3 10 30;.1 10 35;3 10 30;.1 10 35];cH=[1 1.2 3 3.2];
% pH=[.3689 .117 .2673;.4699 .4387 .747;.1091 .8732 .5547;.03815 .5743 .8828];
% o=0;
% for i=1:4
%     o=o-cH(i)*exp(-(sum(aH(i,:).*((x-pH(i,:)).^2))));
% end
% end
% function o = F20(x)
% aH=[10 3 17 3.5 1.7 8;.05 10 17 .1 8 14;3 3.5 1.7 10 17 8;17 8 .05 10 .1 14];
% cH=[1 1.2 3 3.2];
% pH=[.1312 .1696 .5569 .0124 .8283 .5886;.2329 .4135 .8307 .3736 .1004 .9991;...
% .2348 .1415 .3522 .2883 .3047 .6650;.4047 .8828 .8732 .5743 .1091 .0381];
% o=0;
% for i=1:4
%     o=o-cH(i)*exp(-(sum(aH(i,:).*((x-pH(i,:)).^2))));
% end
% end
% function o = F21(x)
% aSH=[4 4 4 4;1 1 1 1;8 8 8 8;6 6 6 6;3 7 3 7;2 9 2 9;5 5 3 3;8 1 8 1;6 2 6 2;7 3.6 7 3.6];
% cSH=[.1 .2 .2 .4 .4 .6 .3 .7 .5 .5];
% o=0;
% for i=1:5
%     o=o-((x-aSH(i,:))*(x-aSH(i,:))'+cSH(i))^(-1);
% end
% end
% function o = F22(x)
% aSH=[4 4 4 4;1 1 1 1;8 8 8 8;6 6 6 6;3 7 3 7;2 9 2 9;5 5 3 3;8 1 8 1;6 2 6 2;7 3.6 7 3.6];
% cSH=[.1 .2 .2 .4 .4 .6 .3 .7 .5 .5];
% o=0;
% for i=1:7
%     o=o-((x-aSH(i,:))*(x-aSH(i,:))'+cSH(i))^(-1);
% end
% end
% function o = F23(x)
% aSH=[4 4 4 4;1 1 1 1;8 8 8 8;6 6 6 6;3 7 3 7;2 9 2 9;5 5 3 3;8 1 8 1;6 2 6 2;7 3.6 7 3.6];
% cSH=[.1 .2 .2 .4 .4 .6 .3 .7 .5 .5];
% o=0;
% for i=1:10
%     o=o-((x-aSH(i,:))*(x-aSH(i,:))'+cSH(i))^(-1);
% end
% end


% %   7. FastFractal "DoubleDip"
% function f=fastfractal_doubledip(x)
% global initial_flag
% persistent o ff
% [ps,D]=size(x);
% if initial_flag==0
%     load fastfractal_doubledip_data
%     ff = FastFractal('DoubleDip', 3, 1, o, D);
%     initial_flag=1;
% end
% f=ff.evaluate(x);
% end