function [T,gbest] =lpso( funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax)
%   此处显示详细说明
rand('state',sum(100*clock));
c1 = 2.0;
c2 = 2.0;
D = Dimension;
sizepop = Particle_Number;
radmin=2;
maxfes=Max_FES;
maxgen = fix(maxfes/sizepop);
if length(popmin)==1
    popmin=repmat(popmin,1,D);
    popmax=repmat(popmax,1,D);
end
if length(Vmin)==1
    Vmin=repmat(Vmin,1,D);
    Vmax=repmat(Vmax,1,D);
end
pop=zeros(sizepop,D);
V=zeros(sizepop,D);
fitness=zeros(sizepop,1);
T=zeros(maxgen,3);

for i = 1:sizepop
    % 随机产生一个种群
    pop(i,:) = popmin+(popmax-popmin).*rand(1,D);    %初始种群
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %初始化速度
end
fitness = feval(funtest,pop,func_num);
fes=sizepop;
pbest = pop;    %个体最佳
fitnesspbest = fitness;%个体最佳适应度值
nbest=pop;
fitnessnbest = fitness;

%个体极值和群体极值
[fitnessgbest,gbestindex] = min(fitness);
gbest = pop(gbestindex,:); 
T(1,1)=fes;
T(1,2)=fitnessgbest; 
T(1,3)=0; 
% 迭代寻优
for i = 1:maxgen
    w= 0.9-0.5*i/maxgen;
    rad=5; % 邻域规模
    if fes>=maxfes
        break;
    end       
    for j = 1:sizepop
        % 速度更新
        V(j,:) = w.*V(j,:) + c1*rand(1,D).*(pbest(j,:) - pop(j,:)) + c2*rand(1,D).*(nbest(j,:) - pop(j,:));      
        %确保速度不超出边界
        V(j,:)=(V(j,:)>Vmax).*Vmax+(V(j,:)<=Vmax).*V(j,:);
        V(j,:)=(V(j,:)<Vmin).*Vmin+(V(j,:)>=Vmin).*V(j,:);
        % 种群更新
        pop(j,:) = pop(j,:) + V(j,:);
        %确保粒子位置不超出边界
        pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
            +(pop(j,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(j,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));

        fitness(j) = feval(funtest,pop(j,:),func_num);
        fes=fes+1;
        if fitness(j) < fitnesspbest(j)
            pbest(j,:) = pop(j,:);
            fitnesspbest(j) = fitness(j);   
        end        
        if fitness(j) < fitnessgbest
            gbest = pop(j,:);
            fitnessgbest = fitness(j);
            gbestindex=j;
        end  
        if rem(fes,sizepop)==0
           T(fix(fes / sizepop),1)=fes;
           T(fix(fes / sizepop),2)=fitnessgbest; 
           T(fix(fes / sizepop),3)=i; 
        end 
    end 
    for j=1:sizepop
        if abs(j-gbestindex)<=rad || abs(j-gbestindex)>=(sizepop-rad)
            nbest(j,:)=gbest;
            fitnessnbest(j) = fitnessgbest;
        else
            if j==1
                for nrad=j-rad:j+rad
                    if nrad<1
                        nrad=nrad+sizepop;%越界处理
                    elseif nrad>sizepop
                        nrad=nrad-sizepop;%越界处理
                    end
                    if fitnesspbest(nrad)<fitnessnbest(j)
                        nbest(j,:)=pbest(nrad,:);%个体的邻域最优
                        fitnessnbest(j) = fitnesspbest(nrad);   
                    end
                end
            else 
                nrad1=j+rad;
                nrad2=j-rad-1;
                if nrad1>sizepop
                    nrad1=nrad1-sizepop;%越界处理
                end
                if nrad2<1
                    nrad2=nrad2+sizepop;%越界处理
                end

                if fitnesspbest(nrad1)<=fitnessnbest(j-1)
                    nbest(j,:)=pbest(nrad1,:);%个体的邻域最优
                    fitnessnbest(j) = fitnesspbest(nrad1); 
                elseif fitnesspbest(nrad1)>fitnessnbest(j-1) && fitnesspbest(nrad2)>fitnessnbest(j-1)
                    nbest(j,:)=nbest(j-1,:);%个体的邻域最优
                    fitnessnbest(j) = fitnessnbest(j-1); 
                else
                    for nrad=j-rad:j+rad-1
                        if nrad<1
                            nrad=nrad+sizepop;%越界处理
                        elseif nrad>sizepop
                            nrad=nrad-sizepop;%越界处理
                        end
                        if fitnesspbest(nrad)<fitnessnbest(j)
                            nbest(j,:)=pbest(nrad,:);%个体的邻域最优
                            fitnessnbest(j) = fitnesspbest(nrad);   
                        end
                    end
                end
            end
        end
    end
end   
T=T(1:fix(maxfes / sizepop),:);
end