function [T,gbest] =alcpso( funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax)
% global funtest
rand('state',sum(100*clock));
w=0.4;
c1 = 2.0;
c2 = 2.0;
D = Dimension;
sizepop = Particle_Number;
maxfes = Max_FES;
maxgen = fix(maxfes/sizepop);
if length(popmin)==1
    popmin=repmat(popmin,1,D);
    popmax=repmat(popmax,1,D);
end

if length(Vmin)==1
    Vmin=repmat(Vmin,1,D);
    Vmax=repmat(Vmax,1,D);
end

pop=zeros(sizepop,D);
V=zeros(sizepop,D);
fitness=zeros(sizepop,1);
T=zeros(maxgen,3);
for i = 1:sizepop
    % 随机产生一个种群
    pop(i,:) = popmin+(popmax-popmin).*rand(1,D);    %初始种群
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %初始化速度
end
fitness = feval(funtest,pop,func_num);
fes=sizepop;
%个体极值和群体极值
fitnesspbest = fitness;
pbest = pop;
[fitnessgbest,bestindex] = min(fitnesspbest);
gbest = pbest(bestindex,:);   
leader=gbest;  %领导粒子
fitnessleader=fitnessgbest;
age=0;        %年龄
lifespan=60;   %寿命
challengingtimes=2;

T(1,1)=fes;
T(1,2)=fitnessgbest;
T(1,3)=0;

% 迭代寻优
for i=1:maxgen
    if fes>=maxfes
        break;
    end
    thetleader=false;
    thetpbest=false;
    thetgbest=false;
    fitnesspbestbak=fitnesspbest;
    for j = 1:sizepop
        % 速度更新
        V(j,:) = w.*V(j,:) + c1*rand(1,D).*(pbest(j,:) - pop(j,:)) + c2*rand(1,D).*(leader - pop(j,:));      
        %确保速度不超出边界
        V(j,:)=(V(j,:)>Vmax).*Vmax+(V(j,:)<=Vmax).*V(j,:);
        V(j,:)=(V(j,:)<Vmin).*Vmin+(V(j,:)>=Vmin).*V(j,:);
        % 种群更新
        pop(j,:) = pop(j,:) + V(j,:);
        %确保粒子位置不超出边界
%         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
%             +(pop(j,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(j,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
            +(pop(j,:)<popmin).*popmin+(pop(j,:)>popmax).*popmax;

        % 适应度值更新
        fitness(j) = feval(funtest,pop(j,:),func_num);
        fes=fes+1;
        if fitness(j) < fitnessleader
            leader=pop(j,:);  %领导粒子
            fitnessleader=fitness(j);
            thetleader=true;
        end
        %pbest和gbest更新
        if fitness(j) < fitnesspbest(j)
            pbest(j,:) = pop(j,:);
            fitnesspbest(j) = fitness(j);        
        end  
        if fitness(j) < fitnessgbest
            gbest = pop(j,:);
            fitnessgbest = fitness(j);
            thetgbest=true;
        end  
        if rem(fes,sizepop)==0
           T(fix(fes / sizepop),1)=fes;
           T(fix(fes / sizepop),2)=fitnessgbest; 
           T(fix(fes / sizepop),3)=i; 
        end          
    end
    if sum(fitnesspbest)<sum(fitnesspbestbak)
        thetpbest= true;
    end
    age = age + 1;
    if thetgbest
        lifespan = lifespan + 2;
    elseif thetpbest
        lifespan = lifespan + 1;
    elseif thetleader

    else % no leading power
        lifespan = lifespan - 1;
    end
    if age >= lifespan % generate and test the challenger
        popbak = pop;
        Vbak = V;
        flag_same = true; % the challenger is the same as the leader
        challenger = leader;
        for d = 1 : D
            if rand < (1 / D)
                challenger(1,d) = unifrnd(popmax(1),popmin(1));
                flag_same = false;
            end
        end
        % ensure that the challenger is different from the leader
        if flag_same
            challenger(randi(D)) = unifrnd(popmax(1),popmin(1));
        end
      
        fitnesschallenger = feval(funtest,pop(j,:),func_num);
        fes=fes+1;
        if fitnesschallenger < fitnessgbest
            gbest = challenger;            
            fitnessgbest = fitnesschallenger; 
        end
        if rem(fes,sizepop)==0
           T(fix(fes / sizepop),1)=fes;
           T(fix(fes / sizepop),2)=fitnessgbest; 
           T(fix(fes / sizepop),3)=i; 
        end  
        flag_improve = false;
        for k = 1 : challengingtimes
            for j = 1 :sizepop
                % update and limit V
                V(j,:) = w*V(j,:) + c1*rand(1,D).*(pbest(j,:) - pop(j,:)) + c2*rand(1,D).*(challenger - pop(j,:));      
                %确保速度不超出边界
                V(j,:)=(V(j,:)>Vmax).*Vmax+(V(j,:)<=Vmax).*V(j,:);
                V(j,:)=(V(j,:)<Vmin).*Vmin+(V(j,:)>=Vmin).*V(j,:);
                % 种群更新
                pop(j,:) = pop(j,:) + V(j,:);
                %确保粒子位置不超出边界
%                 pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
%                         +(pop(j,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(j,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
            +(pop(j,:)<popmin).*popmin+(pop(j,:)>popmax).*popmax;

                % 适应度值更新
                fitness(j) = feval(funtest,pop(j,:),func_num)
                fes=fes+1;
                    %pbest和gbest更新
                if fitness(j) < fitnesspbest(j)
                    pbest(j,:) = pop(j,:);
                    fitnesspbest(j) = fitness(j);
                    flag_improve = true;
                    if fitness(j) < fitnessgbest
                        gbest = pop(j,:);
                        fitnessgbest = fitness(j);
                    end          
                end        
                if fitness(j)< fitnesschallenger
                    challenger = pop(j,:);
                    fitnesschallenger = fitness(j); 
                end
                if rem(fes,sizepop)==0
                   T(fix(fes / sizepop),1)=fes;
                   T(fix(fes / sizepop),2)=fitnessgbest; 
                   T(fix(fes / sizepop),3)=i; 
                end  
            end
            if flag_improve
                leader = challenger; 
                fitnessleader= fitnesschallenger;
                age = 0;
                lifespan = 60;
                break;
            end
        end
        if ~flag_improve
            pop = popbak;
            V = Vbak;
            age = lifespan - 1;
        end
    end
end 
T=T(1:fix(maxfes / sizepop),:);
end