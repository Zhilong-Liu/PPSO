p=[-100,100;-10,10;-100,100;-100,100;-90,90;-100,100;-1.28,1.28;-500,500;-5.12,5.12;-32,32;-600,600;-50,50;-50,50];
p=0.95*p;
tit=["Shift_Sphere";"Shift_Schwefel_2_22";"Shift_Schwefel_1_2";"Shift_Schwefel_2_21";"Shift_Rosenbrock";"Shift_Step";...
    "Shift_Quartic_Noise";"Shift_Weierstrass";"Shift_Rastrigin";"Shift_Ackley";"Shift_Griewank";"Shift_Penalized_1";"Shift_Penalized_2"];
for i=1:13
    o=p(i,1)+(p(i,2)-p(i,1))*rand(1,100);
    save(strcat('D:\Matlab R2020b\bin\文件\Base Benchmark\benchmark\',tit(i),'_data.mat'),'o');
end