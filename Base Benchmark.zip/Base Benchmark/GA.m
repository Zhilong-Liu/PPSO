% Adapted from the original code of Dr. Seyedali Mirjalili


% To watch videos on this algorithm, enrol to my courses with 95% discount using the following links: 

% ************************************************************************************************************************************************* 
%  A course on "Optimization Problems and Algorithms: how to understand, formulation, and solve optimization problems": 
%  https://www.udemy.com/optimisation/?couponCode=MATHWORKSREF
% ************************************************************************************************************************************************* 
%  "Introduction to Genetic Algorithms: Theory and Applications" 
%  https://www.udemy.com/geneticalgorithm/?couponCode=MATHWORKSREF
% ************************************************************************************************************************************************* 

function [T,genebest]  = GA (funtest,func_num,N,M,Max_FES,~,~,low,up)
rand('state',sum(100*clock));
MaxGen = fix(Max_FES/M);
T=zeros(MaxGen,3);
Pc=0.95;
Pm=0.01;
Er=0.2;
if length(low)==1
    low=repmat(low,1,N);
    up=repmat(up,1,N);
end
Gene=zeros(M,N);
fitness=zeros(M,1);
newGene=zeros(M,N);
newfitness=zeros(M,1);
genebest=zeros(1,N);
fitnessbest=inf;
%%  Initialization

for i = 1 : M
    Gene(i,:)=(up - low) .* rand(1,N) +low;
    fitness(i) = feval(funtest,Gene(i,:),func_num);
    if fitness(i)<fitnessbest
        genebest=Gene(i,:);
        fitnessbest=fitness(i);
    end     
end

fes=M;

T(1,1) = fes;
T(1,2) = fitnessbest; 
T(1,3) = 1; 

%% Main loop
for g = 2 : MaxGen

    % Calcualte the fitness values
    for i = 1 : M
        fitness(i) = -feval(funtest,Gene(i,:),func_num);
    end
    fes=fes+M;
    for k = 1: 2: M
        % Selection
        [ parent1, parent2] = selection(Gene,fitness);
        
        % Crossover
        [child1 , child2] = crossover_continious(parent1 , parent2, Pc, N,up,low);
        
        % Mutation
        [child1] = mutation(child1, Pm,up,low);
        [child2] = mutation(child2, Pm,up,low);
        
        newGene(k,:) = child1;
        newGene(k+1,:) = child2;
    end

    for i = 1 : M
        newfitness(i) = - feval(funtest,newGene(i,:),func_num);
    end
    % Elitism
    [ newGene,newfitness ] = elitism(Gene , newGene,fitness,newfitness,Er);
    Gene=newGene;
    fitness=newfitness; 
    
    genebest  = Gene(1,:);
    fitnessbest = fitness(1);
    fitnessbest=-fitnessbest; 
    
    T(g,1) = fes;
    T(g,2) = fitnessbest; 
    T(g,3) = g; 
end  
end


function [parent1, parent2] = selection(Gene,fit)

M = size(Gene,1);

if any(fit < 0 ) 
    % Fitness scaling in case of negative values scaled(f) = a * f + b
    a = 1;
    b = abs( min(  fit )  );
    Scaled_fitness = a .*  fit + b;
    
    normalized_fitness = Scaled_fitness ./ sum(Scaled_fitness);
else
    normalized_fitness = fit ./ sum(fit);
end
%normalized_fitness = [population.Chromosomes(:).fitness] ./ sum([population.Chromosomes(:).fitness]);
[temp_normalized_fitness , sorted_idx] = sort(normalized_fitness , 'descend');
for i = 1 : M
    temp_Gene(i,:) = Gene(sorted_idx(i),:);
%     temp_fitness = fit(sorted_idx(i));
%     temp_normalized_fitness = normalized_fitness(sorted_idx(i));
end
cumsum = zeros(1 , M);
for i = 1 : M
    for j = i : M
        cumsum(i) = cumsum(i) + temp_normalized_fitness(j);
    end
end
R = rand(); % in [0,1]
parent1_idx = M;
for i = 1: length(cumsum)
    if R > cumsum(i)
        parent1_idx = i - 1;
        break;
    end
end
parent2_idx = parent1_idx;
while_loop_stop = 0; % to break the while loop in rare cases where we keep getting the same index
while parent2_idx == parent1_idx
    while_loop_stop = while_loop_stop + 1;
    R = rand(); % in [0,1]
    if while_loop_stop > 20
        break;
    end
    for i = 1: length(cumsum)
        if R > cumsum(i)
            parent2_idx = i - 1;
            break;
        end
    end
end

parent1 = temp_Gene(parent1_idx,:);
parent2 = temp_Gene(parent2_idx,:);

end

function [child1 , child2] = crossover_continious(parent1 , parent2, Pc, dim,up,low)

child1= zeros(1,dim);
child2 = zeros(1,dim);
beta = rand(1,dim);
child1 = beta .* parent1 + (1-beta).*parent2;
child2 = (1-beta) .* parent1 + beta.*parent2;
child1=max(child1,low);
child1=min(child1,up);
child2=max(child2,low);
child2=min(child2,up);
R1 = rand();

if R1 <= Pc
    child1 = child1;
else
    child1 = parent1;
end

R2 = rand();

if R2 <= Pc
    child2 = child2;
else
    child2 = parent2;
end
end

function [child] = mutation(child, Pm, up,low)

Gene_no = length(child);

for k = 1: Gene_no
    R = rand();
    if R < Pm
        child(k) = (up(k) - low(k)) * rand() +low(k);
    end
end

end

function [newpop2, newfit2] = elitism(pop ,newpop,fit,newfit,Er)
 newpop2=zeros(size(pop,1),size(pop,2));
 newfit2=zeros(size(fit,1),size(fit,2));
M = length(fit); % number of individuals 

Elite_no = round(M * Er);

[~ , indx] = sort(fit , 'descend');
    
% The elites from the previous population
for k = 1 : Elite_no
    newpop2(k,:)  = pop(indx(k),:);
    newfit2(k) = fit(indx(k));
end
% The rest from the new population
for k = Elite_no + 1 :  M
    newpop2(k,:)  = newpop(k,:);
    newfit2(k) = newfit(k);
end
end