function [T,gbest] = apso(funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax)
%APSO 此处显示有关此函数的摘要
%   此处显示详细说明
rand('state',sum(100*clock));
c1 = 2.0;
c2 = 2.0;
w = 0.9;
D = Dimension;
sizepop = Particle_Number;
maxfes=Max_FES;
maxgen = fix(maxfes/sizepop);
if length(popmin)==1
    popmin=repmat(popmin,1,D);
    popmax=repmat(popmax,1,D);
end

if length(Vmin)==1
    Vmin=repmat(Vmin,1,D);
    Vmax=repmat(Vmax,1,D);
end
pop=zeros(sizepop,D);
V=zeros(sizepop,D);
fitness=zeros(sizepop,1);
S=zeros(sizepop,1);
T=zeros(maxgen,3);
MeanDis=zeros(sizepop,1);
Status = 'S1';


for i = 1:sizepop
    % 随机产生一个种群
    pop(i,:) = popmin+(popmax-popmin).*rand(1,D);    %初始种群
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %初始化速度
end
fitness = feval(funtest,pop,func_num);
fes=sizepop;
pbest = pop;    %个体最佳
fitnesspbest = fitness;%个体最佳适应度值
%个体极值和群体极值
[fitnessgbest,bestindex] = min(fitnesspbest);
gbest = pbest(bestindex,:); 
T(1,1)=fes;
T(1,2)=fitnessgbest; 
T(1,3)=0; 
% 迭代寻优
for i = 1:maxgen
    if fes>maxfes
        break;
    end
%     variance = 1.0-0.9*i/maxgen;
    variance = 1.0-0.9*fes/maxfes;
%  状态判断
    
    S(i) = MeanD(pop,bestindex,D);
    w = 1/(1+1.5*exp(-2.6*S(i)));   
    if S(i)<0.2
        Status = 'S3';
    end
    if 0.2<=S(i)&&S(i)<0.23
        if strcmp(Status,'S1')||strcmp(Status,'S2')
            Status = 'S2';
        else
            Status = 'S3';
        end
    end
    if 0.23<=S(i)&&S(i)<0.3
        if strcmp(Status,'S2')||strcmp(Status,'S3')
            Status = 'S3';
        else
            Status = 'S2';
        end
    end
    
    if 0.3<=S(i)&&S(i)<0.4
        Status = 'S2';
    end
    if 0.4<=S(i)&&S(i)<0.5
        if strcmp(Status,'S1')||strcmp(Status,'S4')
            Status = 'S1';
        else
            Status = 'S2';
        end
    end
    if 0.5<=S(i)&&S(i)<0.6
        if strcmp(Status,'S2')||strcmp(Status,'S1')
            Status = 'S2';
        else
            Status = 'S1';
        end
    end
    
    if 0.6<=S(i)&&S(i)<0.7
        Status = 'S1';
    end
    if 0.7<=S(i)&&S(i)<0.77
        if strcmp(Status,'S3')||strcmp(Status,'S4')
            Status = 'S4';
        else
            Status = 'S1';
        end
    end
    if 0.77<=S(i)&&S(i)<0.8
        if strcmp(Status,'S4')||strcmp(Status,'S1')
            Status = 'S1';
        else
            Status = 'S4';
        end
    end
    if S(i)>=0.8
        Status ='S4';
    end
%    根据状态调整参数
    
    if strcmp(Status,'S1')
        c1 = c1+(0.05+rand*0.05);
        c2 = c2-(0.05+rand*0.05);
    end
    if strcmp(Status,'S2')
        c1 = c1+(0.025+rand*0.025);
        c2 = c2-(0.025+rand*0.025);
    end
    if strcmp(Status,'S3')
        c1 = c1+(0.025+rand*0.025);
        c2 = c2+(0.025+rand*0.025);
        z=zeros(1,D);
        z(randperm(D,1))=1;
        jump = gbest+(popmin+(popmax-popmin)).*z*normrnd(0,variance.^2);
%         jump=((jump>=popmin)&(jump<=popmax)).*jump...
%                 +(jump<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(jump>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
          jump=((jump>=popmin)&(jump<=popmax)).*jump...
            +(jump<popmin).*popmin+(jump>popmax).*popmax;

        fitnessjump = feval(funtest,jump,func_num);
        fes=fes+1;
        if fitnessjump < fitnessgbest
            pop(bestindex,:) = jump;
            pbest(bestindex,:)=jump;
            fitnesspbest(bestindex) = fitnessjump;
            fitnessgbest = fitnessjump; 
            gbest = jump;
        end
        if rem(fes,sizepop)==0
           T(fix(fes / sizepop),1)=fes;
           T(fix(fes / sizepop),2)=fitnessgbest;
           T(fix(fes / sizepop),3)=i; 
        end 
    end   
    if strcmp(Status,'S4')
        c1 = c1-(0.05+rand*0.05);
        c2 = c2+(0.05+rand*0.05);
    end
    if c1+c2 < 3
        c1 = c1*3/(c1+c2);
        c2 = 3-c1;
    end
    if c1+c2 > 4
        c1 = c1*4/(c1+c2);
        c2 = 4-c1;
    end
    c1 =  max(1.5,min(2.5,c1));
    c2 =  max(1.5,min(2.5,c2));
    for j = 1:sizepop
        V(j,:) = w.*V(j,:) + c1*rand(1,D).*(pbest(j,:) - pop(j,:)) + c2*rand(1,D).*(gbest - pop(j,:));      
        %确保速度不超出边界
        V(j,:)=(V(j,:)>Vmax).*Vmax+(V(j,:)<=Vmax).*V(j,:);
        V(j,:)=(V(j,:)<Vmin).*Vmin+(V(j,:)>=Vmin).*V(j,:);
        % 种群更新
        pop(j,:) = pop(j,:) + V(j,:);
        %确保粒子位置不超出边界
%         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
%             +(pop(j,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(j,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
         pop(j,:)=((pop(j,:)>=popmin)&(pop(j,:)<=popmax)).*pop(j,:)...
            +(pop(j,:)<popmin).*popmin+(pop(j,:)>popmax).*popmax;
        fitness(j) = feval(funtest,pop(j,:),func_num);
        fes=fes+1;
        if fitness(j) < fitnesspbest(j)
            pbest(j,:) = pop(j,:);
            fitnesspbest(j) = fitness(j);   
        end
        if fitness(j) < fitnessgbest
            gbest = pop(j,:);
            fitnessgbest = fitness(j);
        end  
        if rem(fes,sizepop)==0
           T(fix(fes / sizepop),1)=fes;
           T(fix(fes / sizepop),2)=fitnessgbest; 
           T(fix(fes / sizepop),3)=i; 
        end 
    end 
end
T=T(1:fix(maxfes / sizepop),:);
end
function Status = MeanD(x,g,D)
%MEANDISTANCE 此处显示有关此函数的摘要
%   此处显示详细说明
% rows = size(x,1);
MeanDis = zeros(size(x,1),1); 
for i = 1:size(x,1)
    distan = 0;
    for j = 1:size(x,1)
        if i==j
            continue;
        end
        for d = 1:D
            distan = distan + (x(j,d)-x(i,d))^2;
%             distance = sqrt((x(j,1)-x(i,1))^2+(x(j,2)-x(i,2))^2)+distance;
        end
    end
    distance = sqrt(distan);
    MeanDis(i) = distance/(size(x,1)-1);  
end
% Status = MeanDis;

MaxDis = MeanDis(1);
MinDis = MeanDis(1);
for i = 1:size(x,1)
    if MeanDis(i)>MaxDis
        MaxDis = MeanDis(i);
    end
    if MeanDis(i)<MinDis
        MinDis = MeanDis(i);
    end
end
Status = (MeanDis(g)-MinDis)/(MaxDis-MinDis);
end