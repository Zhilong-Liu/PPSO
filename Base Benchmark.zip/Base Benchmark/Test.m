clear;close all;clc;
global initial_flag  
initial_flag=0;
%%
funtest='benchmark_func';
X=[-100,100;-10,10;-100,100;-100,100;-90,90;-100,100;-1.28,1.28;-500,500;-5.12,5.12;-32,32;-600,600;-50,50;-50,50];
Vmax=0.2*(X(:,2)-X(:,1));
Vmin=-Vmax;
thed=[0.01 0.01 100 10 100 0.01 0.1 10 50 0.01 0.01 0.01 0.01];
%%
dime=30;
ps=30;%Common multiple of 2 and 3
fesnum=50000;
testnum=30;
alnum=11;
funnum=13;
for j=1:funnum
    fu(j)=j;
end

for j=1:alnum
    al(j)=j;
end

%%

for i=1:funnum
    for k=1:testnum
        for j=1:alnum
        tic;
        [Result,Gbest]=test( al(j),funtest,fu(i),dime,ps,fesnum,Vmin(fu(i)),Vmax(fu(i)),X(fu(i),1),X(fu(i),2));
        time(i,j,k)=toc;
        result(:,:,i,j,k)=Result;
        solution(:,i,j,k)=Gbest;
        end       
    end
initial_flag=0;
end
%%
%%
function [a,b]=test(al_num,funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax)

if al_num==1     
    fh=str2func('pso_ldiw'); 
    elseif al_num==2  
        fh=str2func('pso_ck'); 
    elseif al_num==3  
        fh=str2func('hpso_tvac'); 
    elseif al_num==4  
        fh=str2func('apso'); 
    elseif al_num==5  
        fh=str2func('cso'); 
    elseif al_num==6  
        fh=str2func('dms_l_pso_l'); 
    elseif al_num==7  
        fh=str2func('GA');
    elseif al_num==8  
        fh=str2func('DE');
    elseif al_num==9  
        fh=str2func('GWO'); 
    elseif al_num==10  
        fh=str2func('ppso');
    elseif al_num==11  
        fh=str2func('lppso');
    elseif al_num==12 
        fh=str2func('lpso');
    elseif al_num==13 
        fh=str2func('clpso'); 
    elseif al_num==14 
        fh=str2func('alcpso');       
    end

    
[a,b]=feval(fh,funtest,func_num,Dimension,Particle_Number,Max_FES,Vmin,Vmax,popmin,popmax);
end