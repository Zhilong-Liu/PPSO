
%% DE Parameters

% MaxIt=1000;      % Maximum Number of Iterations

% nPop=50;        % Population Size

% beta_min=0.2;   % Lower Bound of Scaling Factor
% beta_max=0.8;   % Upper Bound of Scaling Factor
% 
% pCR=0.2;        % Crossover Probability
function [T,gbest] = DE(funtest,func_num,Dimension,Particle_Number,Max_FES,~,~,low,up)
rand('state',sum(100*clock));
D = Dimension;
maxgen=fix(Max_FES/Particle_Number);
ps = Particle_Number;
T=zeros(maxgen,3);
CR=0.8;
%% Initialization

if length(low)==1
    low=repmat(low,1,D);
    up=repmat(up,1,D);
end
beta_min=0.2;
beta_max=0.8;
x=zeros(ps,D);
fitness=zeros(ps,1);
fitnessgbest=inf;
for i = 1:ps
    x(i,:) = low+(up-low).*rand(1,D);    
    fitness(i) = feval(funtest,x(i,:),func_num);
    if fitness(i)<fitnessgbest
        fitnessgbest=fitness(i);
        gbest=x(i,:);
    end       
end
fes=ps;
T(1,1) = fes;
T(1,2) = fitnessgbest; 
T(1,3) = 1; 

%% DE Main Loop

for it=2:maxgen
    
    [r1, r2, r3] = gnR1R2R3(ps);
    for i=1:ps        
        % Mutation
        %beta=unifrnd(beta_min,beta_max);
         beta=rand(1,D).*(beta_max-beta_min)+beta_min;
%         beta=unifrnd(beta_min,beta_max,dim);
        v=x(r1(i),:)+beta.*(x(r2(i),:)-x(r3(i),:));
        v = max(v, low);
		v = min(v, up);
%         end 
        % Crossover
        r4=rand(1,D);
        temp=(r4>CR);
        if all(temp)
            temp(randi(D))=0;
        end
        u=temp.*x(i,:)+(1-temp).*v;
        ufitness = feval(funtest,u,func_num);
        if ufitness<fitness(i)
            x(i,:)=u;
            fitness(i)=ufitness;
        end
        if ufitness<fitnessgbest
            gbest=u;
            fitnessgbest=ufitness;
        end       
    end
fes=fes+ps;  
T(it,1) = fes;
T(it,2) = fitnessgbest; 
T(it,3) = it; 
end
end

function [r1, r2,r3] = gnR1R2R3(NP)


r1=floor(rand(1, NP) * NP) + 1;
r2 = floor(rand(1, NP) * NP) + 1;
%for i = 1 : inf
for i = 1 : 1001
    pos = (r2 == r1);
    if sum(pos) == 0
        break;
    else % regenerate r1 if it is equal to r0
        r2(pos) = floor(rand(1, sum(pos)) * NP) + 1;
    end
    if i > 1000% this has never happened so far
        error('Can not genrate r2 in 1000 iterations');
    end
end

r3 = floor(rand(1, NP) * NP) + 1;
%for i = 1 : inf
for i = 1 : 1001
    pos = ((r3 == r1) | (r3 == r2));
    if sum(pos)==0
        break;
    else % regenerate r2 if it is equal to r0 or r1
        r3(pos) = floor(rand(1, sum(pos)) * NP) + 1;
    end
    if i > 1000 % this has never happened so far
        error('Can not genrate r2 in 1000 iterations');
    end
end
end