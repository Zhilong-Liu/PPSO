%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Gaining-Sharing Knowledge Based Algorithm for Solving Optimization
%%Problems: A Novel Nature-Inspired Algorithm
%% Authors: Ali Wagdy Mohamed, Anas A. Hadi , Ali Khater Mohamed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [bsf_fit_var,bsf_solution] = GSK(funtest,func_num,problem_size,pop_size,G_Max,lb,ub)
rand('seed', sum(100 * clock));

%%%%%%%%%%%%%%%%%%%%%%%% Parameter settings%%%%%%%%%%
KF=0.5;% Knowledge Factor
KR=0.9;%Knowledge Ratio
K=10*ones(pop_size,1);%Knowledge Rate
if length(lb)==1
    lb=repmat(lb,1,D);
    ub=repmat(ub,1,D);
end
popold = zeros(pop_size,problem_size);
pop=popold ;
fitness=inf(pop_size,1);
children_fitness=inf(pop_size,1);
bsf_fit_var=inf;           
%% Initialize the main population
for i = 1 : pop_size

    popold(i,:) = lb + rand(1, problem_size) .* (ub - lb);
    pop(i,:) = popold(i,:); % the old population becomes the current population
    fitness(i) = feval(funtest,pop(i,:),func_num);
    if fitness(i) < bsf_fit_var
        bsf_fit_var = fitness(i);
        bsf_solution=pop(i,:);
    end
end
            
%% main loop
%             while nfes < max_nfes
for g=1:G_Max
    D_Gained_Shared_Junior=ceil((problem_size)*(1-g/G_Max).^K);
    D_Gained_Shared_Senior=problem_size-D_Gained_Shared_Junior;
    pop = popold; % the old population becomes the current population

    [~, indBest] = sort(fitness, 'ascend');
    [Rg1, Rg2, Rg3] = Gained_Shared_Junior_R1R2R3(indBest);

    [R1, R2, R3] = Gained_Shared_Senior_R1R2R3(indBest);
    R01=1:pop_size;
    Gained_Shared_Junior=zeros(pop_size, problem_size);
    ind1=fitness(R01)>fitness(Rg3);

    if(sum(ind1)>0)
        Gained_Shared_Junior (ind1,:)= pop(ind1,:) + KF*ones(sum(ind1), problem_size) .* (pop(Rg1(ind1),:) - pop(Rg2(ind1),:)+pop(Rg3(ind1), :)-pop(ind1,:)) ;
    end
    ind1=~ind1;
    if(sum(ind1)>0)
        Gained_Shared_Junior(ind1,:) = pop(ind1,:) + KF*ones(sum(ind1), problem_size) .* (pop(Rg1(ind1),:) - pop(Rg2(ind1),:)+pop(ind1,:)-pop(Rg3(ind1), :)) ;
    end
    R0=1:pop_size;
    Gained_Shared_Senior=zeros(pop_size, problem_size);
    ind=fitness(R0)>fitness(R2);
    if(sum(ind)>0)
        Gained_Shared_Senior(ind,:) = pop(ind,:) + KF*ones(sum(ind), problem_size) .* (pop(R1(ind),:) - pop(ind,:) + pop(R2(ind),:) - pop(R3(ind), :)) ;
    end
    ind=~ind;
    if(sum(ind)>0)
        Gained_Shared_Senior(ind,:) = pop(ind,:) + KF*ones(sum(ind), problem_size) .* (pop(R1(ind),:) - pop(R2(ind),:) + pop(ind,:) - pop(R3(ind), :)) ;
    end
    Gained_Shared_Junior = boundConstraint(Gained_Shared_Junior, pop, lb,ub);
    Gained_Shared_Senior = boundConstraint(Gained_Shared_Senior, pop, lb,ub);


    D_Gained_Shared_Junior_mask=rand(pop_size, problem_size)<=(D_Gained_Shared_Junior(:, ones(1, problem_size))./problem_size); 
    D_Gained_Shared_Senior_mask=~D_Gained_Shared_Junior_mask;

    D_Gained_Shared_Junior_rand_mask=rand(pop_size, problem_size)<=KR*ones(pop_size, problem_size);
    D_Gained_Shared_Junior_mask=and(D_Gained_Shared_Junior_mask,D_Gained_Shared_Junior_rand_mask);

    D_Gained_Shared_Senior_rand_mask=rand(pop_size, problem_size)<=KR*ones(pop_size, problem_size);
    D_Gained_Shared_Senior_mask=and(D_Gained_Shared_Senior_mask,D_Gained_Shared_Senior_rand_mask);
    ui=pop;

    ui(D_Gained_Shared_Junior_mask) = Gained_Shared_Junior(D_Gained_Shared_Junior_mask);
    ui(D_Gained_Shared_Senior_mask) = Gained_Shared_Senior(D_Gained_Shared_Senior_mask);

    for i = 1 : pop_size
        children_fitness(i) = feval(funtest,ui(i,:),func_num);
        if children_fitness(i) < bsf_fit_var
            bsf_fit_var = children_fitness(i);
            bsf_solution = ui(i, :);
        end

    end

    [fitness, Child_is_better_index] = min([fitness, children_fitness], [], 2);

    popold = pop;
    popold(Child_is_better_index == 2, :) = ui(Child_is_better_index == 2, :);

   % fprintf('NFES:%d, bsf_fit:%1.6e,pop_Size:%d,D_Gained_Shared_Junior:%2.2e,D_Gained_Shared_Senior:%2.2e\n', nfes,bsf_fit_var,pop_size,problem_size*sum(sum(D_Gained_Shared_Junior))/(pop_size*problem_size),problem_size*sum(sum(D_Gained_Shared_Senior))/(pop_size*problem_size))

end % end while loop
end
function [R1, R2, R3] = Gained_Shared_Junior_R1R2R3(indBest)


pop_size = length(indBest);
R0=1:pop_size;
R1=[];
R2=[];
R3=[];

for i=1:pop_size
    ind=find(indBest==i);
    if(ind==1)% best
    R1(i)=indBest(2);
    R2(i)=indBest(3);
    elseif(ind==pop_size)% worst
    R1(i)=indBest(pop_size-2);
    R2(i)=indBest(pop_size-1);
    else
    R1(i)=indBest(ind-1);
    R2(i)=indBest(ind+1);
    end
end

R3 = floor(rand(1, pop_size) * pop_size) + 1;

for i = 1 : 99999999
    pos = ((R3 == R2) | (R3 == R1) | (R3 == R0));
    if sum(pos)==0
        break;
    else % regenerate r2 if it is equal to r0 or r1
        R3(pos) = floor(rand(1, sum(pos)) * pop_size) + 1;
    end
    if i > 1000 % this has never happened so far
        error('Can not genrate R3 in 1000 iterations');
    end
end

end

function [R1, R2, R3] = Gained_Shared_Senior_R1R2R3(indBest)
pop_size = length(indBest);
R1=indBest(1:round(pop_size*0.1));
R1rand = ceil(length(R1) * rand(pop_size, 1));
R1 = R1(R1rand);
R2=indBest(round(pop_size*0.1)+1:round(pop_size*0.9));
R2rand = ceil(length(R2) * rand(pop_size, 1));
R2 = R2(R2rand);

R3=indBest(round(pop_size*0.9)+1:end);
R3rand = ceil(length(R3) * rand(pop_size, 1));
R3 = R3(R3rand);

end

function vi = boundConstraint (vi, pop, lb,ub)

% if the boundary constraint is violated, set the value to be the middle
% of the previous value and the bound
%

[NP, ~] = size(pop);  % the population size and the problem's dimension

%% check the lower bound
xl = repmat(lb, NP, 1);

pos = vi < xl;
vi(pos) = (pop(pos) + xl(pos)) / 2;

%% check the upper bound
xu = repmat(ub, NP, 1);
pos = vi > xu;
vi(pos) = (pop(pos) + xu(pos)) / 2;
end


