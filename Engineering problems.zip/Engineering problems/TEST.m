clear;close all;clc;
global initial_flag  
initial_flag=0;
%%
funtest='engineering_func';
funame=["Welded_beam";"Tension_compression_spring";"Pressure_vessel";"Speed_reducer";"Gear_train";"Himmelblau";"Three_bar_truss";"Stepped_cantilever_beam";"Multiple_disc_clutch_brake";"Hydrodynamic_thrust_bearing"]; 

%%
dime=[4 3 4 7 4 5 2 10 5 4];
ps=30;
iternum=100;
testnum=10;
alnum=9;
funnum=3;
for j=1:funnum
    fu(j)=j;
end
for j=1:alnum
    al(j)=j;
end
%%

for i=1:funnum
    [down,up,dim]=benchmark_functions_details(fu(i));
    for k=1:testnum
        for j=1:alnum      
%         tic;
        [Result,Gbest]=test( al(j),funtest,fu(i),dim,ps,iternum,down',up');
%         time(i,j,k)=toc;
        result(i,j,k)=Result;
        solution{i,j,k}=Gbest;
        end       
    end
end
%%
%%
function [a,b]=test(al_num,funtest,func_num,Dimension,Particle_Number,Max_ITER,popmin,popmax)

if al_num==1     
    fh=str2func('GA'); 
    elseif al_num==2  
        fh=str2func('DE'); 
    elseif al_num==3  
        fh=str2func('GWO'); 
    elseif al_num==4  
        fh=str2func('MFO'); 
    elseif al_num==5  
        fh=str2func('GSK'); 
    elseif al_num==6  
        fh=str2func('GSA'); 
    elseif al_num==7  
        fh=str2func('MPA');
    elseif al_num==8  
        fh=str2func('PPSO');
    elseif al_num==9  
        fh=str2func('LPPSO'); 
    end
[a,b]=feval(fh,funtest,func_num,Dimension,Particle_Number,Max_ITER,popmin,popmax);
end