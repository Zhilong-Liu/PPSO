function f=engineering_func(x,func_num)
   if func_num==1      fhd=str2func('Welded_beam'); 
    elseif func_num==2  fhd=str2func('Tension_compression_spring'); 
    elseif func_num==3  fhd=str2func('Pressure_vessel'); 
    elseif func_num==4  fhd=str2func('Speed_reducer'); 
    elseif func_num==5  fhd=str2func('Gear_train'); 
    elseif func_num==6  fhd=str2func('Himmelblau'); 
    elseif func_num==7  fhd=str2func('Three_bar_truss'); 
    elseif func_num==8  fhd=str2func('Stepped_cantilever_beam');
    elseif func_num==9  fhd=str2func('Multiple_disc_clutch_brake'); 
    elseif func_num==10  fhd=str2func('Hydrodynamic_thrust_bearing'); 
   end
f=feval(fhd,x);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 	1.WELDED BEAM DESIGN PROBLEM DEFINITION 
function cost=Welded_beam(x)
    P = 6000; % APPLIED TIP LOAD
    E = 30e6; % YOUNGS MODULUS OF BEAM
    G = 12e6; % SHEAR MODULUS OF BEAM
    tem = 14; % LENGTH OF CANTILEVER PART OF BEAM
    PCONST = 100000; % PENALTY FUNCTION CONSTANT
    TAUMAX = 13600; % MAXIMUM ALLOWED SHEAR STRESS
    SIGMAX = 30000; % MAXIMUM ALLOWED BENDING STRESS
    DELTMAX = 0.25; % MAXIMUM ALLOWED TIP DEFLECTION
    M =  P*(tem+x(2)/2); % BENDING MOMENT AT WELD POINT
    R = sqrt((x(2)^2)/4+((x(1)+x(3))/2)^2); % SOME CONSTANT
    J =  2*(x(1)*x(2)/sqrt(2)*((x(2)^2)/12+((x(1)+x(3))/2)^2)); % POLAR MOMENT OF INERTIA
    cost =  1.10471*x(1)^2*x(2)+0.04811*x(3)*x(4)*(14+x(2)); % OBJECTIVE FUNCTION
    SIGMA = (6*P*tem)/(x(4)*x(3)^2); % BENDING STRESS
    DELTA = (4*P*tem^3)/(E*x(3)^3*x(4)); % TIP DEFLECTION
    PC = 4.013*E*sqrt((x(3)^2*x(4)^6)/36)*(1-x(3)*sqrt(E/(4*G))/(2*tem))/(tem^2); % BUCKLING LOAD
    TAUP =  P/(sqrt(2)*x(1)*x(2)); % 1ST DERIVATIVE OF SHEAR STRESS
    TAUPP = (M*R)/J; % 2ND DERIVATIVE OF SHEAR STRESS
    TAU = sqrt(TAUP^2+2*TAUP*TAUPP*x(2)/(2*R)+TAUPP^2); % SHEAR STRESS
    G1 = TAU-TAUMAX; % MAX SHEAR STRESS CONSTRAINT
    G2 =  SIGMA-SIGMAX; % MAX BENDING STRESS CONSTRAINT
    %G3 = L(1)-L(4); % WELD COVERAGE CONSTRAINT
    G3=DELTA-DELTMAX;
    G4=x(1)-x(4);
    G5=P-PC;
    G6=0.125-x(1); 
    %G4 = 0.10471*L(1)^2+0.04811*L(3)*L(4)*(14+L(2))-5; % MAX COST CONSTRAINT
    %G5 =  0.125-L(1); % MAX WELD THICKNESS CONSTRAINT
    %G6 =  DELTA-DELTMAX; % MAX TIP DEFLECTION CONSTRAINT
    %G7 =  P-PC; % BUCKLING LOAD CONSTRAINT
    G7=1.10471*x(1)^2+0.04811*x(3)*x(4)*(14+x(2))-5;
    cost = cost + PCONST*(max(0,G1)^2+max(0,G2)^2+...
        max(0,G3)^2+max(0,G4)^2+max(0,G5)^2+...
        max(0,G6)^2+max(0,G7)^2); % PENALTY FUNCTION
end

% 	2.TENSION/COMPRESSION SPRING DESIGN PROBLEM DEFINITION 
function cost=Tension_compression_spring(x)    

    PCONST = 100; % PENALTY FUNCTION CONSTANT
    cost=(x(3)+2)*x(2)*(x(1)^2);
    G1=1-(x(2)^3*x(3))/(71785*x(1)^4);
    G2=(4*x(2)^2-x(1)*x(2))/(12566*(x(2)*x(1)^3-x(1)^4))+1/(5108*x(1)^2)-1;
    G3=1-(140.45*x(1))/(x(2)^2*x(3));
    G4=((x(1)+x(2))/1.5)-1;

    cost = cost + PCONST*(max(0,G1)^2++max(0,G2)^2+...
        max(0,G3)^2+max(0,G4)^2); % PENALTY FUNCTION
end


% 	3.Pressure Vessel design
function cost=Pressure_vessel(x)
    PCONST=10000;  % PENALTY FUNCTION CONSTANT
    cost= 0.6224*x(1)*x(3)*x(4)+ 1.7781*x(2)*x(3)^2 + 3.1661 *x(1)^2*x(4) + 19.84 * x(1)^2*x(3);
    G1= -x(1)+ 0.0193*x(3);
    G2=  -x(2) + 0.00954* x(3);
    G3=  -pi*x(3)^2*x(4)-(4/3)* pi*x(3)^3 +1296000;
    G4= x(4) - 240;
    cost =cost + PCONST*(max(0,G1)^2+max(0,G2)^2+...
        max(0,G3)^2+max(0,G4)^2); % PENALTY FUNCTION
end


% 	4.Gear Train design
function cost=Speed_reducer(x)
    PCONST=10000;  % PENALTY FUNCTION CONSTANT
    cost=0.7854*x(1)*x(2)^2*(3.3333*x(3)^2-14.9334*x(3)-43.0934)-1.508*x(1)*(x(6)^2+x(7)^2)+7.4777*(x(6)^3+x(7)^3)+0.7854*(x(4)*x(6)^2+x(5)*x(7)^2);
    G1=27/(x(1)*x(2)^2*x(3))-1;
    G2=397.5/(x(1)*x(2)^2*x(3)^2);
    G3=1.93*x(4)^3/(x(2)*x(3)*x(6)^4);
    G4=1.93*x(5)^3/(x(2)*x(3)*x(7)^4);
    G5=1.0/(110*x(6)^3)*((745.0*x(4)/x(2)*x(3))^2+16.9*(10)^6)^(1/2)-1;
    G6=1.0/(85*x(7)^3)*((745.0*x(5)/x(2)*x(3))^2+157.5*(10)^6)^1/2-1;
    G7=x(2)*x(3)/40;
    G8=5*x(2)/(x(1))-1;
    G9=x(1)/(12*x(2))-1;
    G10=(1.5*x(6)+1.9)/(x(4))-1;
    G11=(1.1*x(7)+1.9)/(x(5))-1;
    cost =cost+ PCONST*(max(0,G1)^2+max(0,G2)^2+...
        max(0,G3)^2+max(0,G4)^2+max(0,G5)^2+max(0,G6)^2+max(0,G7)^2+max(0,G8)^2+max(0,G9)^2+max(0,G10)^2+max(0,G11)^2); % PENALTY FUNCTION
end

% 	5.Gear Train design
function cost=Gear_train(x)
    %PCONST=10000;  % PENALTY FUNCTION CONSTANT
    cost=((1/6.931)- floor (x(1))*floor (x(2))/floor (x(3))*floor (x(4)))^2;
end

% 	6.Himmelblau's Problem
function cost=Himmelblau(x)
    PCONST=10000;  % PENALTY FUNCTION CONSTANT
    cost= 5.3578547* x(3)^2 + 0.8356891 *x(1)*x(5)+ 37.293239*x(1)-40792.141;
    G1= 85.334407 +0.0056858*x(1)*x(5)+0.0006262*x(1)*x(4)-0.0022053*x(3)*x(5);
    G2= 80.51249+ 0.0071317*x(2)*x(5)+0.0029955*x(1)*x(2)-0.0021813*x(3)^2;
    G3= 9.300961+0.0047026*x(3)*x(5)+0.0012547*x(1)*x(3)-0.0019085*x(3)*x(4);
    cost =cost + PCONST*(max(0,G1)^2+max(0,G2)^2+ max(0,G3)^2);
end


% 	7.Three Bar Truss Design
function cost=Three_bar_truss(x)
    PCONST=10000;  % PENALTY FUNCTION CONSTANT
    P=2;
    RU=2;
    L=100;
    cost=(2*(2*x(1))^1/2+x(2))*L;
    G1=((2)^1/2*x(1)+ x(2))/ ((2)^1/2*x(1)^2+ 2*x(1)*x(2))*P-RU;
    G2= (x(2))/ ((2)^1/2*x(1)^2+2*x(1)*x(2))*P-RU;
    G3= (1)/(x(1)+ (2)^1/2*x(2))*P-RU;
    cost =cost + PCONST*(max(0,G1)^2+max(0,G2)^2+ max(0,G3)^2);

end

% 	8.Stepped Cantilever Beam Design
function cost=Stepped_cantilever_beam(x)
    PCONST=10000;  % PENALTY FUNCTION CONSTANT
    L=100;
    P=50000;
    E=2*107;
    cost=(x(1)*x(6)+x(2)*x(7)+x(3)*x(8)+x(4)*x(9)+x(5)*x(10))*L;
    G1= ((600*P)/(x(5)*x(10)^2))-14000;
    G2= ((6*P*2*L)/(x(4)*x(9)^2))-14000;
    G3= ((6*P*3*L)/(x(3)*x(8)^2))-14000;
    G4= ((6*P*4*L)/(x(2)*x(7)^2))-14000;
    G5= ((6*P*5*L)/(x(1)*x(6)^2))-14000;
    G6= (((P*L^3)/(3*E))*(125/L))-2.7;
    G7=(x(10)/x(5))-20;
    G8=(x(9)/x(4))-20;
    G9=(x(8)/x(3))-20;
    G10=(x(7)/x(2))-20;
    G11=(x(6)/x(1))-20;
    cost =cost + PCONST*(max(0,G1)^2+max(0,G2)^2+...
        max(0,G3)^2+max(0,G4)^2+max(0,G5)^2+max(0,G6)^2+max(0,G7)^2+max(0,G8)^2+max(0,G9)^2+max(0,G10)^2+max(0,G11)^2); % PENALTY FUNCTION

end

% 	9.Multiple Disc Clutch Brake Design
function cost=Multiple_disc_clutch_brake(x)
    PCONST=100000;  % PENALTY FUNCTION CONSTANT
    DR=20;
    % T=3;
    L=30;
    % Z=10;
    VSR=10;
    MU=0.5;
    S=1.5;
    MS=40;
    MF=3;
    n=250;
    P=1;
    I=55;
    T=15;
    % F=1000;
    % RI=80;
    % % RO=110;
    MH=(2/3)*MU*x(4)*x(5)*((x(2)^3-x(1)^3)/(x(2)^2-x(1)^2));
    PRZ=x(4)/pi*(x(2)^2-x(1)^2);
    VSR1= (2/90)*pi*n*((x(2)^3-x(1)^3)/(x(2)^2-x(1)^2));
    T1= (I*pi*n)/(30*(MH+MF));
    cost=pi*x(3)*( x(2)^2-x(1)^2)*(x(5)+1)*8*P;
    G1= x(2)-x(1)-DR;
    G2= L-(x(5)+1)*x(3);
    G3= P-PRZ;
    G4= P*VSR-PRZ*VSR;
    G5=VSR-VSR1;
    G6= T-T1;
    G7= MH-S*MS;
    G8= T1;
    cost =cost + PCONST*(max(0,G1)^2+max(0,G2)^2+...
        max(0,G3)^2+max(0,G4)^2+max(0,G5)^2+max(0,G6)^2+max(0,G7)^2+max(0,G8)^2);
end

% 	10.Hydrodynamic Thrust Bearing Design 
function cost=Hydrodynamic_thrust_bearing(x)
    PCONST=100000;  % PENALTY FUNCTION CONSTANT
    WS=101000;
    PMAX=1000;
    DTM=50;
    HM=0.001;
    Y=0.0307;
    C=0.5;
    C1=10.04;
    n=-3.55;
    Ne=750;
    Ge=386.4;
    P= (log10(log10(8.1222*1e6*x(3)+0.8)-C1))/n;
    DT= 2*(10^P-560);
    EF= 9336* x(4)*Y*C*DT;
    H= ((2*pi*Ne)/60)^2*((2*pi*x(3))/EF)*((x(1)^4/4)-((x(2)^4)/4));
    P0= (6*x(3)*x(4)/pi*H^3)* log(x(1)/x(2));
    W=((pi*P0)/2)*((x(1)^2*x(2)^2)/log(x(1)/x(2)));
    cost=((x(4)*P0)/0.7)+EF;
    G1= W-WS;
    G2=PMAX-P0;
    G3= DTM-DT;
    G4= H-HM;
    G5=x(1)-x(2);
    G6= 0.001- (Y/(Ge*P0))*(x(4)/2*pi*x(1)*H);
    G7= 5000- W/(pi*(x(1)^2*x(2)^2));
    cost =cost + PCONST*(max(0,G1)^2+max(0,G2)^2+...
        max(0,G3)^2+max(0,G4)^2+max(0,G5)^2+max(0,G6)^2+max(0,G7)^2);
end