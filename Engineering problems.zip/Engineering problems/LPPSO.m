function [fitnessgbest,gbest] =LPPSO( funtest,func_num,Dimension,Particle_Number,Max_IETR,popmin,popmax)
%   此处显示详细说明
rand('state',sum(100*clock));
D = Dimension;
maxgen=Max_IETR;
sizepop=Particle_Number;
periodnum=maxgen/8;
undulate=0.4;
rad=ceil(0.05*sizepop);
if length(popmin)==1
    popmin=repmat(popmin,1,D);
    popmax=repmat(popmax,1,D);
end

Vmin=-0.2*(popmax-popmin);
Vmax=-Vmin;

pop=zeros(sizepop,D);
V=zeros(sizepop,D);
fitness=zeros(sizepop,1);

for i = 1:sizepop
    % 随机产生一个种群
    pop(i,:) = popmin+(popmax-popmin).*rand(1,D);    %初始种群
    V(i,:) = Vmin+(Vmax-Vmin).*rand(1,D);  %初始化速度
    fitness(i) = feval(funtest,pop(i,:),func_num);
end

pbest = pop;    %个体最佳
fitnesspbest = fitness;%个体最佳适应度值
nbest = pop;    
fitnessnbest = fitness;
[sortfitness,sortfitnessindex] = sort(fitness);%排序
gbest = pop(sortfitnessindex(1),:);   %全局最佳
fitnessgbest = sortfitness(1);   %全局最佳适应度值
gbestindex = sortfitnessindex(1);

% 迭代寻优
for i = 2:maxgen
%     w= 0.5*(1-i/maxgen)+0.2*(cos(2*periodnum*pi*i/maxgen)+1);
    w= 0.5+0.15*cos(2*periodnum*pi*i/maxgen);
    variance = 0.2+0.1*sin(2*periodnum*pi*i/maxgen);
%     variance = 0.15;

    for j = 1:sizepop
        c1=1*(sin(2*pi*periodnum*i/maxgen+pi*j/2/sizepop+pi/4)+1);
        c2=1*(sin(2*pi*periodnum*i/maxgen+pi*j/2/sizepop+5*pi/4)+1);
        k=sortfitnessindex(j); 
        h=randi(sizepop);
        while h==k
            h=randi(sizepop);
        end          
        if fitnesspbest(k)<fitnesspbest(h)
            hbest=pbest(k,:);
        else
            hbest=pbest(h,:);
        end
        
        V(k,:) = w*V(k,:) + c1*rand(1,D).*(hbest - pop(k,:))...
             + c2*rand(1,D).*(nbest(k,:) - pop(k,:));               
        %确保速度不超出边界
        V(k,:)=(V(k,:)>Vmax).*Vmax+(V(k,:)<=Vmax).*V(k,:);
        V(k,:)=(V(k,:)<Vmin).*Vmin+(V(k,:)>=Vmin).*V(k,:);
        % 种群更新
        pop(k,:) = pop(k,:) + V(k,:);
        %确保粒子位置不超出边界
%         pop(k,:)=((pop(k,:)>=popmin)&(pop(k,:)<=popmax)).*pop(k,:)...
%             +(pop(k,:)<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(pop(k,:)>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
        pop(k,:)=((pop(k,:)>=popmin)&(pop(k,:)<=popmax)).*pop(k,:)...
            +(pop(k,:)<popmin).*popmin+(pop(k,:)>popmax).*popmax;
 
        % 适应度值更新
        fitness(k) = feval(funtest,pop(k,:),func_num);
        %pbest和gbest更新
        if fitness(k) < fitnesspbest(k)
            pbest(k,:) = pop(k,:);
            fitnesspbest(k) = fitness(k);
        end
        if fitness(k) < fitnessgbest
            gbest = pop(k,:);
            fitnessgbest = fitness(k);
            gbestindex=k;
        end  

        gam=undulate*sizepop*sin(2*periodnum*pi*i/maxgen);
        if j<gam%&&sin(2*periodnum*pi*i/maxgen)>0&&sin(2*periodnum*pi*i/maxgen)<0&&cos(2*periodnum*pi*i/maxgen)<0
            z=zeros(1,D);
            z(randperm(D,1))=1;
            jump = pop(k,:)+(popmax-popmin).*z.*normrnd(0,variance);
%             jump=((jump>=popmin)&(jump<=popmax)).*jump...
%                 +(jump<popmin).*(popmin+0.25.*(popmax-popmin).*rand(1,D))+(jump>popmax).*(popmax-0.25.*(popmax-popmin).*rand(1,D));
            jump=((jump>=popmin)&(jump<=popmax)).*jump...
                +(jump<popmin).*popmin+(jump>popmax).*popmax;            
            fitnessjump = feval(funtest,jump,func_num);
            if fitnessjump < fitnesspbest(k)
                pbest(k,:) = jump;
                fitnesspbest(k) = fitnessjump;
            end 
            if fitnessjump < fitnessgbest
                gbest = jump;
                fitnessgbest=fitnessjump;
                gbestindex=k;
            end 
        end
    end 
%%
    for j=1:sizepop
        if abs(j-gbestindex)<=rad || abs(j-gbestindex)>=(sizepop-rad)
            nbest(j,:)=gbest;
            fitnessnbest(j) = fitnessgbest;
        else
            if j==1
                for nrad=j-rad:j+rad
                    if nrad<1
                        nrad=nrad+sizepop;%越界处理
                    elseif nrad>sizepop
                        nrad=nrad-sizepop;%越界处理
                    end
                    if fitnesspbest(nrad)<fitnessnbest(j)
                        nbest(j,:)=pbest(nrad,:);%个体的邻域最优
                        fitnessnbest(j) = fitnesspbest(nrad);   
                    end
                end
            else 
                nrad1=j+rad;
                nrad2=j-rad-1;
                if nrad1>sizepop
                    nrad1=nrad1-sizepop;%越界处理
                end
                if nrad2<1
                    nrad2=nrad2+sizepop;%越界处理
                end

                if fitnesspbest(nrad1)<=fitnessnbest(j-1)
                    nbest(j,:)=pbest(nrad1,:);%个体的邻域最优
                    fitnessnbest(j) = fitnesspbest(nrad1); 
                elseif fitnesspbest(nrad1)>fitnessnbest(j-1) && fitnesspbest(nrad2)>fitnessnbest(j-1)
                    nbest(j,:)=nbest(j-1,:);%个体的邻域最优
                    fitnessnbest(j) = fitnessnbest(j-1); 
                else
                    for nrad=j-rad:j+rad-1
                        if nrad<1
                            nrad=nrad+sizepop;%越界处理
                        elseif nrad>sizepop
                            nrad=nrad-sizepop;%越界处理
                        end
                        if fitnesspbest(nrad)<fitnessnbest(j)
                            nbest(j,:)=pbest(nrad,:);%个体的邻域最优
                            fitnessnbest(j) = fitnesspbest(nrad);   
                        end
                    end
                end
            end
        end
    end
%%
    [~,sortfitnessindex] = sort(fitness);   
end 
end